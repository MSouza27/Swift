import UIKit

let nome = "Steve"
var sobrenome: String? = "Jobs"

print("\(nome) \(sobrenome ?? "Wozniak")")

if let nomeDesembrulhado = sobrenome {
    print("\(nome) \(nomeDesembrulhado)")
    
}else {
    print("\(nome) \(sobrenome ?? "Wozniak")")
}
